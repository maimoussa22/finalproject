/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project1;

import java.applet.*;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseListener;

/**
 *
 * @author Administrator
 */
public class ProjectApplet extends Applet    {

     
    
     int Startx,Starty,Endx,Endy ;
    
    public void init() {
        
        resize(640,480);
    }
   public void paint(Graphics g)
    {
         Graphics2D Draw = (Graphics2D)g.create();
         Startx=100;
         Starty=100;
         Endx=200;
         Endy=200;
         DrawOval(  Draw);
    }

    

public void DrawOval(Graphics2D Draw)
{
 double d=Math.sqrt(Math.pow((Startx-Endx), 2)+Math.pow((Starty-Endy), 2));
 
Draw.fillOval(Startx, Starty, (int)d, (int)d/2);
 
  Draw.drawOval(Startx+200, Starty, (int)d, (int)d/2);
  
 
}
     
    
}
