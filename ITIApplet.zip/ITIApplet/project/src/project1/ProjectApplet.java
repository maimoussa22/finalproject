/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project1;

import java.applet.*;
import java.awt.Graphics;
import java.awt.Graphics2D;

/**
 *
 * @author Administrator
 */
public class ProjectApplet extends Applet   {

     
   
    int Startx,Starty,Endx,Endy;
    
    public void init() {
        resize(640,480);
  }
   public void paint(Graphics g)
    {
        Graphics2D Draw = (Graphics2D)g.create();
        Startx=100;
        Endx=200;
        Starty=100;
        Endy=200;
        DrawCircle(Draw);
    }

     

public void DrawCircle(Graphics2D Draw)
{
double d=Math.sqrt(Math.pow((Startx-Endx), 2)+Math.pow((Starty-Endy), 2));
   System.out.print(d);

Draw.fillOval(Startx+200, Starty, (int)d, (int)d);

    Draw.drawOval(Startx, Starty, (int)d, (int)d);

}

}
