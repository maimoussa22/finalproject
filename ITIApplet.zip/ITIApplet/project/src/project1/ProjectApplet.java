/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project1;

import java.applet.*;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseListener;
import javax.swing.JComboBox;

/**
 *
 * @author Administrator
 */
public class ProjectApplet extends Applet   {

     
    
    int Startx,Starty,Endx,Endy;
     
    public void init() {
         resize(640,480);
    }
   public void paint(Graphics g)
    {
        Graphics2D Draw = (Graphics2D)g.create();
        Startx=100;
        Starty=100;
        Endx=200;
        Endy=250;
        DrawRect(  Draw);
    }

   
public void DrawRect( Graphics2D Draw)
{
 int MaxXStart,MaxYStart,MaxXEnd,MaxYEnd;
if(Startx>Endx)
{
MaxXEnd=Startx;
MaxXStart=Endx;
}
else
{
MaxXEnd= Endx;
MaxXStart=Startx;
}

if(Starty>Endy)
{
MaxYEnd=Starty;
MaxYStart=Endy;
}
else
{
MaxYEnd= Endy;
MaxYStart=Starty;
}
 
       Draw.fillRect(MaxXStart, MaxYStart, MaxXEnd-MaxXStart, MaxYEnd-MaxYStart);
  
    Draw.drawRect(MaxXStart+300, MaxYStart, MaxXEnd-MaxXStart, MaxYEnd-MaxYStart);
 
}




    
}
